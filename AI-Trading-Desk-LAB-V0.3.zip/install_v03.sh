#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
REPO="${1:-$(pwd)}"
cd "$REPO"

mkdir -p trading_lab tests scripts docs
cp "$SRC/trading_lab/research.py" trading_lab/research.py
cp "$SRC/trading_lab/blind.py" trading_lab/blind.py
cp "$SRC/trading_lab/target.py" trading_lab/target.py
cp "$SRC/tests/test_research_v03.py" tests/test_research_v03.py
cp "$SRC/scripts/run_research_loop.py" scripts/run_research_loop.py
cp "$SRC/docs/CONTINUOUS_RESEARCH_V03.md" docs/CONTINUOUS_RESEARCH_V03.md
cp "$SRC/pyproject.toml" pyproject.toml
chmod +x scripts/run_research_loop.py

if ! grep -q "LAB V0.3 — continuous research + blind boxes" README.md; then
  cat "$SRC/README_V03_APPEND.md" >> README.md
fi

python -m unittest discover -s tests -v
SMOKE_DB="$(mktemp -u /tmp/research-v03-smoke-XXXXXX.sqlite3)"
python scripts/run_research_loop.py --smoke --cycles 10 --db "$SMOKE_DB"
rm -f "$SMOKE_DB"

echo "V0.3 INSTALL + TESTS: PASS"
