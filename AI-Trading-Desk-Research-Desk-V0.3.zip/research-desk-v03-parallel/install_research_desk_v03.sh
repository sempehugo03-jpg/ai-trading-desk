#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$PWD}"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

cp "$PATCH_DIR/trading_lab/agent_provider.py" trading_lab/agent_provider.py
cp "$PATCH_DIR/trading_lab/desk_agents.py" trading_lab/desk_agents.py
cp "$PATCH_DIR/trading_lab/parallel_agents.py" trading_lab/parallel_agents.py
cp "$PATCH_DIR/trading_lab/quant_desk.py" trading_lab/quant_desk.py
cp "$PATCH_DIR/trading_lab/agent_desk.py" trading_lab/agent_desk.py
cp "$PATCH_DIR/scripts/run_agent_desk.py" scripts/run_agent_desk.py
cp "$PATCH_DIR/tests/test_research_desk_v03_parallel.py" tests/test_research_desk_v03_parallel.py
cp "$PATCH_DIR/docs/RESEARCH_DESK_V03.md" docs/RESEARCH_DESK_V03.md
cp "$PATCH_DIR/pyproject.toml" pyproject.toml

echo "== V0.3 targeted tests =="
python -m unittest tests.test_research_desk_v03_parallel -v

echo "== Full regression suite =="
python -m unittest discover -s tests -v

echo "Research Desk V0.3 installed. Campaign databases and market data were not modified."
