
## Research Desk V0.1

Research agents are now wired to a safe declarative strategy DSL. LLMs propose and challenge hypotheses; trusted local code calculates P&L and all quantitative gates. A fair scheduler allows research to continue while candidates wait for one-shot blind evaluation or future shadow data. See `docs/RESEARCH_DESK_V01.md`.
