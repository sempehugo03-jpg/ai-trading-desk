#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$PWD}"
SRC="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
cp "$SRC/trading_lab/strategy_dsl.py" trading_lab/
cp "$SRC/trading_lab/agent_provider.py" trading_lab/
cp "$SRC/trading_lab/desk_agents.py" trading_lab/
cp "$SRC/trading_lab/quant_desk.py" trading_lab/
cp "$SRC/trading_lab/agent_desk.py" trading_lab/
cp "$SRC/scripts/run_agent_desk.py" scripts/
chmod +x scripts/run_agent_desk.py
cp "$SRC/tests/test_research_desk_v01.py" tests/
cp "$SRC/docs/RESEARCH_DESK_V01.md" docs/
export V04_SRC="$SRC"
python - <<'PY'
from pathlib import Path
p=Path('pyproject.toml')
s=p.read_text()
s=s.replace('version = "0.3.0"','version = "0.4.0"')
s=s.replace('description = "Deterministic multi-asset research lab with continuous staged research and one-shot blind-box evaluation. No live execution."','description = "Continuous multi-agent research desk with safe strategy DSL, blind-box gates and no live execution."')
p.write_text(s)
readme=Path('README.md')
append=Path(__import__('os').environ.get('V04_APPEND_PATH','/dev/null'))
marker='## Research Desk V0.1'
if marker not in readme.read_text():
    readme.write_text(readme.read_text()+Path(__import__('os').environ['V04_SRC']).joinpath('README_APPEND.md').read_text())
PY
python -m unittest discover -s tests -q
printf '\nResearch Desk V0.1 installed and tests passed.\n'
