#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-$PWD}"
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$TARGET"
mkdir -p trading_lab scripts tests docs
cp "$HERE"/trading_lab/*.py trading_lab/
cp "$HERE"/scripts/*.py scripts/
cp "$HERE"/tests/*.py tests/
cp "$HERE"/docs/*.md docs/
chmod +x scripts/run_agent_desk.py scripts/benchmark_research_engine.py
python -m unittest discover -s tests -q
PYTHONPATH=. python scripts/benchmark_research_engine.py
printf '\nResearch Desk V0.2 installed. Existing data/ and runs/ were preserved.\n'
printf 'Resume Campaign 001 with:\n'
printf 'python scripts/run_agent_desk.py --db runs/campaign-001.sqlite3 --cycles 100 --batch-size 5 --max-candidates 5 --confirm-api-costs\n'
