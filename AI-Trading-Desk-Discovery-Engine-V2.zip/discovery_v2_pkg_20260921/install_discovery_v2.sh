#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$PWD}"
PATCH="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
cp "$PATCH/trading_lab/discovery_v2.py" trading_lab/discovery_v2.py
cp "$PATCH/trading_lab/discovery_runner_v2.py" trading_lab/discovery_runner_v2.py
cp "$PATCH/scripts/run_discovery_v2.py" scripts/run_discovery_v2.py
cp "$PATCH/scripts/status_discovery_v2.py" scripts/status_discovery_v2.py
cp "$PATCH/tests/test_discovery_v2.py" tests/test_discovery_v2.py
cp "$PATCH/docs/DISCOVERY_ENGINE_V2.md" docs/DISCOVERY_ENGINE_V2.md
cp "$PATCH/pyproject.toml" pyproject.toml
chmod +x scripts/run_discovery_v2.py scripts/status_discovery_v2.py
python -m unittest tests.test_discovery_v2 -v
python -m unittest discover -s tests -v
echo "Discovery Engine V2 installé. Données et anciennes DB inchangées."
