#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-$PWD}"
PATCH="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

cp "$PATCH/trading_lab/desk_v1.py" trading_lab/desk_v1.py
cp "$PATCH/trading_lab/propfirm.py" trading_lab/propfirm.py
cp "$PATCH/trading_lab/portfolio_v1.py" trading_lab/portfolio_v1.py
cp "$PATCH/scripts/run_desk_v1.py" scripts/run_desk_v1.py
cp "$PATCH/scripts/fetch_desk_v1_data.cjs" scripts/fetch_desk_v1_data.cjs
cp "$PATCH/scripts/check_desk_v1_data.py" scripts/check_desk_v1_data.py
cp "$PATCH/scripts/quarantine_desk_v1_data.py" scripts/quarantine_desk_v1_data.py
cp "$PATCH/tests/test_desk_v1.py" tests/test_desk_v1.py
cp "$PATCH/docs/DESK_V1.md" docs/DESK_V1.md
cp "$PATCH/pyproject.toml" pyproject.toml
chmod +x scripts/run_desk_v1.py scripts/fetch_desk_v1_data.cjs scripts/check_desk_v1_data.py scripts/quarantine_desk_v1_data.py

echo "== Desk V1 targeted tests =="
python -m unittest tests.test_desk_v1 -v
echo "== Full regression suite =="
python -m unittest discover -s tests -v
echo "Desk V1 installed. Existing campaign DBs and market data were not modified."
